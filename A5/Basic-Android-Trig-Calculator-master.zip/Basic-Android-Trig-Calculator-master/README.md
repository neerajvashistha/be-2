Basic-Android-Trig-Calculator
====================
A general purpose trig calculator

development tools
====================
Antlr - http://www.antlr.org/ 

Eclipse - https://www.eclipse.org/

Android SDK - http://developer.android.com/sdk/index.html?hl=sk
