/** Automatically generated file. DO NOT MODIFY */
package com.example.chem_calc;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}